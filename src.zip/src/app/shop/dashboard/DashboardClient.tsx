"use client";

import { useState, useTransition } from "react";
import Image from "next/image";
import { useRouter } from "next/navigation";
import shopCover from "@/image/shopCover.png";
import shopProfile from "@/image/shopProfile.png";
import { useToastStore } from "@/zustand/toastStore";
import { useAuthStore } from "@/zustand/authStore";
import { updateShopBio, updateShopInfo } from "./actions";
import {
  Mail,
  Telephone,
  Pin,
  EditOne,
  Plus,
  Refresh,
  Package,
  Store,
  Dollar,
  PlusCircle,
  Cog,
  ListCheck
} from "@mynaui/icons-react";

interface DashboardClientProps {
  shop: {
    shop_uid: string;
    shop_name: string;
    shop_email: string;
    shop_phone: string;
    shop_location: string;
    shop_description: string;
    shop_bio: string | null;
  };
  user: {
    username: string;
  };
}

export default function DashboardClient({ shop, user }: DashboardClientProps) {
  const router = useRouter();
  const addToast = useToastStore((s) => s.addToast);
  const { setActiveShop } = useAuthStore();
  const [isPending, startTransition] = useTransition();

  const [isEditingBio, setIsEditingBio] = useState(false);
  const [bioText, setBioText] = useState(shop.shop_bio || "");

  const [isEditingInfo, setIsEditingInfo] = useState(false);
  const [infoEmail, setInfoEmail] = useState(shop.shop_email);
  const [infoPhone, setInfoPhone] = useState(shop.shop_phone);
  const [infoLocation, setInfoLocation] = useState(shop.shop_location);

  const handleSwitchToCustomer = () => {
    startTransition(async () => {
      try {
        const response = await fetch("/api/switch-shop", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "X-Requested-With": "XMLHttpRequest",
          },
          body: JSON.stringify({ activeShopUid: null }),
        });
        const result = await response.json();

        if (response.ok) {
          addToast("Switched to Customer Mode", "success");
          setActiveShop(null);
          router.replace(result.redirect || "/profile");
        } else {
          addToast(result.message || "Failed to switch mode", "error");
        }
      } catch (error) {
        addToast("Network error! Please try again.", "error");
      }
    });
  };

  const handleSaveBio = async () => {
    const res = await updateShopBio(shop.shop_uid, bioText);
    if (res.success) {
      addToast("Bio updated successfully!", "success");
      setIsEditingBio(false);
    } else {
      addToast(res.error || "Failed to update bio", "error");
    }
  };

  // Handle Info Save
  const handleSaveInfo = async (e: React.FormEvent) => {
    e.preventDefault();
    const res = await updateShopInfo(shop.shop_uid, {
      email: infoEmail,
      phone: infoPhone,
      location: infoLocation,
    });
    if (res.success) {
      addToast("Shop information updated successfully!", "success");
      setIsEditingInfo(false);
    } else {
      addToast(res.error || "Failed to update information", "error");
    }
  };

  return (
    <div className="flex flex-col lg:flex-row w-full h-full min-h-screen bg-[#f7f7f9] text-[#1a1a1a]">
      {/* LEFT COLUMN: Profile & Settings */}
      <aside className="w-full lg:w-96 bg-white border-r border-[#eef0f3] flex flex-col shrink-0 overflow-y-auto">
        
        {/* Cover & Profile Images */}
        <div className="relative">
          <div className="h-32 w-full bg-[#f3f4f6] relative overflow-hidden">
            <Image
              src={shopCover}
              alt="Shop Cover"
              fill
              className="object-cover"
            />
            <div className="absolute inset-0 bg-black/10" />
          </div>

          <div className="px-5 pb-4 relative flex flex-col items-center">
            {/* Profile image overlapping cover */}
            <div className="w-24 h-24 rounded-full border-4 border-white bg-white shadow-sm overflow-hidden -mt-12 flex justify-center items-center">
              <Image
                src={shopProfile}
                alt="Shop Profile"
                className="object-cover"
              />
            </div>
            
            <h2 className="mt-2 text-xl font-bold tracking-tight text-center">{shop.shop_name}</h2>
            <p className="text-xs text-[#787878] font-light mt-0.5">
              Owned by <span className="font-medium text-[#1a1a1a]">{user.username}</span>
            </p>
          </div>
        </div>

        {/* Bio Section */}
        <div className="px-6 py-5 border-t border-[#f4f5f7] flex flex-col gap-3">
          <div className="flex justify-between items-center">
            <span className="text-xs font-semibold text-[#BA5B55] uppercase tracking-wider">Bio</span>
            {!isEditingBio && (
              <button
                onClick={() => setIsEditingBio(true)}
                className="text-[#787878] hover:text-[#BA5B55] transition-colors"
                title="Edit Bio"
              >
                <EditOne size={16} />
              </button>
            )}
          </div>

          {isEditingBio ? (
            <div className="flex flex-col gap-2">
              <textarea
                value={bioText}
                onChange={(e) => setBioText(e.target.value)}
                placeholder="Tell customers about your shop..."
                rows={3}
                className="w-full text-sm p-2 border border-[#eaeaea] focus:border-[#BA5B55] outline-none resize-none font-light bg-[#fafafa]"
              />
              <div className="flex justify-end gap-2">
                <button
                  onClick={() => {
                    setBioText(shop.shop_bio || "");
                    setIsEditingBio(false);
                  }}
                  className="px-3 py-1 text-xs border border-[#eaeaea] hover:bg-gray-50 text-[#787878]"
                >
                  Cancel
                </button>
                <button
                  onClick={handleSaveBio}
                  className="px-3 py-1 text-xs bg-[#BA5B55] text-white hover:bg-[#BA5B55]/90"
                >
                  Save
                </button>
              </div>
            </div>
          ) : bioText ? (
            <p className="text-sm text-[#4f4f4f] leading-relaxed font-light">{bioText}</p>
          ) : (
            <button
              onClick={() => setIsEditingBio(true)}
              className="flex items-center justify-center gap-1.5 py-4 border border-dashed border-[#d1d5db] hover:border-[#BA5B55] hover:text-[#BA5B55] text-xs font-medium text-[#787878] transition-all bg-gray-50/50"
            >
              <Plus size={16} />
              <span>Add Bio</span>
            </button>
          )}
        </div>

        {/* About Info Section */}
        <div className="px-6 py-5 border-t border-[#f4f5f7] flex flex-col gap-4 flex-1">
          <div className="flex justify-between items-center">
            <span className="text-xs font-semibold text-[#BA5B55] uppercase tracking-wider">About Info</span>
            <button
              onClick={() => setIsEditingInfo(true)}
              className="text-[#787878] hover:text-[#BA5B55] transition-colors flex items-center gap-1 text-xs"
            >
              <EditOne size={14} />
              <span>Edit info</span>
            </button>
          </div>

          <div className="flex flex-col gap-3.5 text-sm text-[#4f4f4f]">
            <div className="flex items-center gap-3">
              <Mail size={16} className="text-[#BA5B55] shrink-0" />
              <span className="truncate" title={shop.shop_email}>{shop.shop_email}</span>
            </div>
            <div className="flex items-center gap-3">
              <Telephone size={16} className="text-[#BA5B55] shrink-0" />
              <span>{shop.shop_phone}</span>
            </div>
            <div className="flex items-center gap-3">
              <Pin size={16} className="text-[#BA5B55] shrink-0" />
              <span>{shop.shop_location}</span>
            </div>
          </div>
        </div>
      </aside>

      {/* RIGHT COLUMN: Navbar & Dashboard Main Content */}
      <main className="flex-1 flex flex-col overflow-hidden">
        
        {/* Top Navbar */}
        <header className="h-16 bg-white border-b border-[#eef0f3] flex items-center justify-between px-6 shrink-0">
          <div className="flex items-center gap-2 cursor-pointer" onClick={() => router.push("/shop/dashboard")}>
            <Store stroke={1.5} size={24} className="text-[#BA5B55]" />
            <span className="font-bold text-lg tracking-wider text-[#1a1a1a]">
              NASHWA <span className="font-light text-[#BA5B55]">BUSINESS</span>
            </span>
          </div>

          <button
            onClick={handleSwitchToCustomer}
            disabled={isPending}
            className="flex items-center gap-2 px-3.5 py-1.5 border border-[#eaeaea] hover:border-[#BA5B55] hover:text-[#BA5B55] text-xs font-medium text-[#787878] transition-all bg-white cursor-pointer"
          >
            <Refresh size={14} />
            <span>Switch to Customer</span>
          </button>
        </header>

        {/* Dashboard Content Area */}
        <div className="flex-1 p-6 overflow-y-auto flex flex-col gap-6">
          
          {/* Welcome Alert */}
          <div className="bg-white border border-[#eef0f3] p-6 shadow-sm rounded-sm">
            <h1 className="text-xl font-bold text-[#1a1a1a]">Welcome to your Dashboard, {user.username}!</h1>
            <p className="text-xs text-[#787878] font-light mt-1">
              Here you can manage your shop, view statistics, fulfill orders, and list new products for the university market.
            </p>
          </div>

          {/* Statistics Grid */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="bg-white border border-[#eef0f3] p-5 shadow-sm flex items-center gap-4">
              <div className="p-3 bg-[#BA5B55]/10 rounded-full text-[#BA5B55]">
                <Package size={24} />
              </div>
              <div>
                <p className="text-xs text-[#787878] font-light uppercase tracking-wider">Total Products</p>
                <h3 className="text-2xl font-bold mt-0.5">0</h3>
              </div>
            </div>

            <div className="bg-white border border-[#eef0f3] p-5 shadow-sm flex items-center gap-4">
              <div className="p-3 bg-blue-50 text-blue-600 rounded-full">
                <ListCheck size={24} />
              </div>
              <div>
                <p className="text-xs text-[#787878] font-light uppercase tracking-wider">Active Orders</p>
                <h3 className="text-2xl font-bold mt-0.5">0</h3>
              </div>
            </div>

            <div className="bg-white border border-[#eef0f3] p-5 shadow-sm flex items-center gap-4">
              <div className="p-3 bg-emerald-50 text-emerald-600 rounded-full">
                <Dollar size={24} />
              </div>
              <div>
                <p className="text-xs text-[#787878] font-light uppercase tracking-wider">Total Revenue</p>
                <h3 className="text-2xl font-bold mt-0.5">৳0</h3>
              </div>
            </div>
          </div>

          {/* Quick Actions & Recent Activity layout */}
          <div className="grid grid-cols-1 xl:grid-cols-3 gap-6 items-start">
            
            {/* Quick Actions */}
            <div className="xl:col-span-1 bg-white border border-[#eef0f3] p-5 shadow-sm flex flex-col gap-4">
              <h3 className="text-sm font-semibold text-[#1a1a1a]">Quick Actions</h3>
              <div className="flex flex-col gap-2">
                <button className="flex items-center gap-2.5 p-3 border border-[#eaeaea] hover:border-[#BA5B55] hover:text-[#BA5B55] transition-all text-xs font-medium text-left bg-white">
                  <PlusCircle size={16} className="text-[#BA5B55]" />
                  Add New Product
                </button>
                <button className="flex items-center gap-2.5 p-3 border border-[#eaeaea] hover:border-[#BA5B55] hover:text-[#BA5B55] transition-all text-xs font-medium text-left bg-white">
                  <ListCheck size={16} className="text-[#BA5B55]" />
                  Manage Orders
                </button>
                <button className="flex items-center gap-2.5 p-3 border border-[#eaeaea] hover:border-[#BA5B55] hover:text-[#BA5B55] transition-all text-xs font-medium text-left bg-white">
                  <Cog size={16} className="text-[#BA5B55]" />
                  Shop Settings
                </button>
              </div>
            </div>

            {/* Recent Products / Activity Placeholder */}
            <div className="xl:col-span-2 bg-white border border-[#eef0f3] p-5 shadow-sm flex flex-col gap-4 min-h-62.5">
              <h3 className="text-sm font-semibold text-[#1a1a1a]">Recent Products</h3>
              
              <div className="flex-1 flex flex-col items-center justify-center text-center py-8">
                <Package stroke={1} size={40} className="text-[#787878]/30 mb-2" />
                <p className="text-xs text-[#787878] font-light">No products uploaded yet.</p>
                <button className="text-xs text-[#BA5B55] font-medium hover:underline mt-1">
                  Upload your first product
                </button>
              </div>
            </div>
          </div>
        </div>
      </main>

      {/* EDIT INFO MODAL */}
      {isEditingInfo && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white border border-[#eaeaea] w-full max-w-md p-6 shadow-xl rounded-sm flex flex-col gap-4 animate-in fade-in zoom-in-95 duration-200">
            <div>
              <h3 className="text-lg font-bold">Edit Shop Information</h3>
              <p className="text-xs text-[#787878] font-light mt-0.5">
                Update the public contact details for your shop.
              </p>
            </div>

            <form onSubmit={handleSaveInfo} className="flex flex-col gap-4">
              <div className="flex flex-col gap-1">
                <label className="text-xs font-semibold text-[#787878]">Shop Email</label>
                <input
                  type="email"
                  value={infoEmail}
                  onChange={(e) => setInfoEmail(e.target.value)}
                  required
                  className="w-full text-sm p-2 border border-[#eaeaea] focus:border-[#BA5B55] outline-none font-light"
                />
              </div>

              <div className="flex flex-col gap-1">
                <label className="text-xs font-semibold text-[#787878]">Shop Phone</label>
                <input
                  type="text"
                  value={infoPhone}
                  onChange={(e) => setInfoPhone(e.target.value)}
                  required
                  className="w-full text-sm p-2 border border-[#eaeaea] focus:border-[#BA5B55] outline-none font-light"
                />
              </div>

              <div className="flex flex-col gap-1">
                <label className="text-xs font-semibold text-[#787878]">Location</label>
                <input
                  type="text"
                  value={infoLocation}
                  onChange={(e) => setInfoLocation(e.target.value)}
                  required
                  className="w-full text-sm p-2 border border-[#eaeaea] focus:border-[#BA5B55] outline-none font-light"
                />
              </div>

              <div className="flex justify-end gap-2 mt-2">
                <button
                  type="button"
                  onClick={() => {
                    setInfoEmail(shop.shop_email);
                    setInfoPhone(shop.shop_phone);
                    setInfoLocation(shop.shop_location);
                    setIsEditingInfo(false);
                  }}
                  className="px-4 py-2 border border-[#eaeaea] hover:bg-gray-50 text-xs font-medium text-[#787878]"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-[#BA5B55] border border-[#BA5B55] hover:bg-white hover:text-[#BA5B55] text-white text-xs font-medium transition-all"
                >
                  Save Changes
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
