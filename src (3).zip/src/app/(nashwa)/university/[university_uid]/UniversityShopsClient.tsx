"use client";

import { useState } from "react";
import Image from "next/image";
import Link from "next/link";
import { Store, ArrowLeft, Maximize, UserPlus, Heart, Message, Share, Bookmark } from "@mynaui/icons-react";
import { useToastStore } from "@/zustand/toastStore";
import Lightbox from "@/components/Lightbox";
import ProductCard from "@/app/(nashwa)/home/ProductCard";
import type { FeedProduct } from "@/app/(nashwa)/home/HomeFeedClient";

type ShopRow = {
  shop_uid: string;
  owner_uid: string;
  shop_name: string;
  shop_location: string;
  shop_description: string;
  profile_photo_url: string | null;
  owner_username: string;
  followers_count: number;
  is_following: boolean;
};

interface UniversityShopsClientProps {
  university: {
    university_uid: string;
    university_name: string;
    description: string | null;
    logo_url: string | null;
  };
  shops: ShopRow[];
  shopImages: Record<string, string[]>;
  currentUid: string | null;
  initialProducts: FeedProduct[];
  initialFollowedShops: string[];
  initialSavedProducts: string[];
  initialReactedProducts: string[];
}

export default function UniversityShopsClient({
  university,
  shops,
  shopImages,
  currentUid,
  initialProducts,
  initialFollowedShops,
  initialSavedProducts,
  initialReactedProducts,
}: UniversityShopsClientProps) {
  const addToast = useToastStore((s) => s.addToast);
  const [lightboxSrc, setLightboxSrc] = useState<string | null>(null);

  

  const [products, setProducts] = useState<FeedProduct[]>(initialProducts);
  const [followedShops, setFollowedShops] = useState<Set<string>>(new Set(initialFollowedShops));
  const [savedProducts, setSavedProducts] = useState<Set<string>>(new Set(initialSavedProducts));
  const [reactedProducts, setReactedProducts] = useState<Set<string>>(new Set(initialReactedProducts));

  

  const handleFollowToggle = async (shopUid: string, shopName: string) => {
    if (!currentUid) {
      addToast("Please sign in to follow shops", "error");
      return;
    }
    const isFollowing = followedShops.has(shopUid);
    setFollowedShops((prev) => {
      const next = new Set(prev);
      if (isFollowing) next.delete(shopUid);
      else next.add(shopUid);
      return next;
    });

    try {
      const response = await fetch(`/api/shops/${shopUid}/follow`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "X-Requested-With": "XMLHttpRequest",
        },
      });
      const result = await response.json();
      if (!response.ok) {
        addToast(result.error || "Failed to update follow status.", "error");
        

        setFollowedShops((prev) => {
          const next = new Set(prev);
          if (isFollowing) next.add(shopUid);
          else next.delete(shopUid);
          return next;
        });
        return;
      }
      addToast(
        result.following
          ? `Following ${shopName}`
          : `Unfollowed ${shopName}`,
        "success"
      );
    } catch {
      addToast("Network error. Please try again.", "error");
      

      setFollowedShops((prev) => {
        const next = new Set(prev);
        if (isFollowing) next.add(shopUid);
        else next.delete(shopUid);
        return next;
      });
    }
  };

  return (
    <div className="flex-1 flex flex-col min-h-0 bg-white border border-gray-150 font-sans max-w-7xl mx-auto w-full rounded-none">
      {/* Top Banner */}
      <header className="border-b border-[#f0f0f0] p-6 flex-initial">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div
              className="relative h-16 w-16 shrink-0 overflow-hidden border border-[#ece7e5] bg-[#fafafa] cursor-pointer hover:opacity-90 transition-opacity rounded-none"
              onClick={() => {
                if (university.logo_url) {
                  setLightboxSrc(university.logo_url);
                }
              }}
            >
              {university.logo_url ? (
                <Image
                  src={university.logo_url}
                  alt={university.university_name}
                  fill
                  className="object-cover"
                />
              ) : (
                <div className="flex h-full w-full items-center justify-center text-[#BA5B55]">
                  <Store size={18} />
                </div>
              )}
            </div>

            <div>
              <p className="text-xs uppercase tracking-[0.25em] text-[#9aa6a3] font-bold">community</p>
              <h1 className="mt-1 text-2xl sm:text-3xl font-semibold tracking-tight text-[#232323]">
                {university.university_name}
              </h1>
              <p className="mt-1 text-xs sm:text-sm text-[#7b7b7b]">
                {shops.length} {shops.length === 1 ? "shop" : "shops"} joined this community
              </p>
            </div>
          </div>

          <Link
            href="/university"
            className="inline-flex items-center gap-2 text-xs font-semibold text-[#ba5b55] hover:text-[#9c403a] hover:underline"
          >
            <ArrowLeft size={14} />
            Back to universities
          </Link>
        </div>
        {university.description && (
          <p className="mt-4 text-xs text-gray-500 leading-normal max-w-2xl bg-gray-50 p-3.5 border border-gray-100 font-light rounded-none">
            {university.description}
          </p>
        )}
      </header>

      {/* Columns Area */}
      <div className="flex-1 flex flex-col md:flex-row min-h-0 overflow-hidden bg-[#fbfbfc]">
        {/* Left Column: Shops List */}
        <section className="w-full md:w-1/3 border-b md:border-b-0 md:border-r border-[#f0f0f0] p-6 flex flex-col min-h-0">
          <h2 className="text-sm font-bold text-[#1f1f1f] uppercase tracking-wider mb-4 shrink-0">
            Shops Joined ({shops.length})
          </h2>
          <div className="flex-1 overflow-y-auto custom-scrollbar flex flex-col gap-4 pr-1">
            {shops.length > 0 ? (
              shops.map((shop) => {
                const isShopFollowing = followedShops.has(shop.shop_uid);
                return (
                  <article
                    key={shop.shop_uid}
                    className="border border-[#ece7e5] p-4 bg-white flex flex-col justify-between hover:shadow-xs hover:border-[#BA5B55]/30 transition-all rounded-none gap-3"
                  >
                    <div>
                      <div className="flex items-center gap-3">
                        <div
                          className="relative h-12 w-12 shrink-0 overflow-hidden border border-[#eadfdb] bg-[#f5f1ee] cursor-pointer hover:opacity-90 rounded-none"
                          onClick={() =>
                            shop.profile_photo_url && setLightboxSrc(shop.profile_photo_url)
                          }
                        >
                          {shop.profile_photo_url ? (
                            <Image
                              src={shop.profile_photo_url}
                              alt={shop.shop_name}
                              fill
                              className="object-cover"
                            />
                          ) : (
                            <div className="flex h-full w-full items-center justify-center text-[#BA5B55]">
                              <Store size={16} />
                            </div>
                          )}
                        </div>

                        <div className="min-w-0 flex-1">
                          <h3 className="truncate text-sm font-semibold text-[#1f1f1f]">
                            {shop.shop_name}
                          </h3>
                          <p className="truncate text-xs text-[#8a8a8a] font-light">
                            @{shop.owner_username}
                          </p>
                        </div>
                      </div>

                      {shop.shop_description && (
                        <p className="mt-3 text-xs text-gray-500 line-clamp-2 leading-relaxed">
                          {shop.shop_description}
                        </p>
                      )}
                    </div>

                    <div className="flex flex-wrap items-center justify-between gap-2 border-t border-gray-50 pt-3 mt-1 text-[11px] text-gray-400">
                      <span>{shop.shop_location}</span>
                      <span>{shop.followers_count + (isShopFollowing ? (shop.is_following ? 0 : 1) : (shop.is_following ? -1 : 0))} followers</span>
                    </div>

                    <div className="flex gap-2.5 mt-1">
                      <Link
                        href={`/shop/${shop.shop_uid}`}
                        className="flex-1 text-center border border-[#e6e2df] py-1.5 text-xs font-semibold text-[#666] hover:border-[#ba5b55] hover:text-[#ba5b55] transition-colors rounded-none"
                      >
                        Visit Shop
                      </Link>

                      <button
                        type="button"
                        onClick={() => handleFollowToggle(shop.shop_uid, shop.shop_name)}
                        className={`flex-1 text-center py-1.5 border text-xs font-semibold transition-all rounded-none cursor-pointer ${
                          isShopFollowing
                            ? "border-[#ba5b55] bg-[#ba5b55] text-white hover:bg-white hover:text-[#ba5b55]"
                            : "border-[#dcdcdc] text-[#787878] hover:border-[#ba5b55] hover:text-[#ba5b55]"
                        }`}
                      >
                        {isShopFollowing ? "Following" : "Follow"}
                      </button>
                    </div>
                  </article>
                );
              })
            ) : (
              <div className="border border-dashed border-[#e5e5e5] bg-[#fafafa] p-8 text-center text-xs text-[#9a9a9a] font-light rounded-none">
                No shops listed.
              </div>
            )}
          </div>
        </section>

        {/* Right Column: All Posts */}
        <section className="w-full md:w-2/3 p-6 flex flex-col min-h-0">
          <h2 className="text-sm font-bold text-[#1f1f1f] uppercase tracking-wider mb-4 shrink-0">
            Feed Posts ({products.length})
          </h2>
          <div className="flex-1 overflow-y-auto custom-scrollbar flex flex-col gap-4 pr-1">
            {products.length > 0 ? (
              products.map((product) => (
                <ProductCard
                  key={product.product_uid}
                  product={product}
                  currentUserId={currentUid}
                  currentUserRole={null}
                  isFollowing={followedShops.has(product.shop_uid)}
                  isSaved={savedProducts.has(product.product_uid)}
                  hasReacted={reactedProducts.has(product.product_uid)}
                  onFollowChange={(shopUid, following) => {
                    setFollowedShops((prev) => {
                      const next = new Set(prev);
                      if (following) next.add(shopUid);
                      else next.delete(shopUid);
                      return next;
                    });
                  }}
                  onSaveChange={(prodUid, saved) => {
                    setSavedProducts((prev) => {
                      const next = new Set(prev);
                      if (saved) next.add(prodUid);
                      else next.delete(prodUid);
                      return next;
                    });
                  }}
                  onReactChange={(prodUid, reacted) => {
                    setReactedProducts((prev) => {
                      const next = new Set(prev);
                      if (reacted) next.add(prodUid);
                      else next.delete(prodUid);
                      return next;
                    });
                  }}
                />
              ))
            ) : (
              <div className="border border-dashed border-[#e5e5e5] bg-[#fafafa] p-12 text-center text-sm text-[#9a9a9a] font-light rounded-none">
                No active posts/products found from shops in this community.
              </div>
            )}
          </div>
        </section>
      </div>

      {lightboxSrc && (
        <Lightbox src={lightboxSrc} onClose={() => setLightboxSrc(null)} alt="Preview Media" />
      )}
    </div>
  );
}
